
export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-4 text-center">
        <p>&copy; {new Date().getFullYear()} Ads Finder. Todos os direitos reservados.</p>
        <div className="flex justify-center space-x-4 mt-4">
          <a href="/legal" className="text-gray-400 hover:text-white">Legal</a>
          <a href="/terms" className="text-gray-400 hover:text-white">Termos de Serviço</a>
          <a href="/privacy" className="text-gray-400 hover:text-white">Política de Privacidade</a>
        </div>
      </div>
    </footer>
  );
}


