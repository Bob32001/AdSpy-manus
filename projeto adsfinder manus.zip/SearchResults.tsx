
import React from 'react';

interface Creative {
  type: 'image' | 'video';
  url: string;
}

interface Ad {
  id: string;
  name: string;
  text: string;
  platform: string;
  country: string;
  startDate: string;
  creatives: Creative[];
  link: string;
}

interface SearchResultsProps {
  ads: Ad[];
  loading: boolean;
  error: string | null;
}

export default function SearchResults({ ads, loading, error }: SearchResultsProps) {
  if (loading) {
    return <div className="text-center text-gray-600">Carregando anúncios...</div>;
  }

  if (error) {
    return <div className="text-center text-red-600">Erro: {error}</div>;
  }

  if (ads.length === 0) {
    return <div className="text-center text-gray-600">Nenhum anúncio encontrado. Tente uma busca diferente.</div>;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {ads.map((ad) => (
        <div key={ad.id} className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-2">{ad.name}</h3>
          <p className="text-gray-700 mb-4">{ad.text}</p>
          <div className="mb-4">
            {ad.creatives.map((creative, index) => (
              <div key={index} className="mb-2">
                {creative.type === 'image' && (
                  <img src={creative.url} alt="Creative" className="w-full h-auto rounded-md" />
                )}
                {creative.type === 'video' && (
                  <video controls src={creative.url} className="w-full h-auto rounded-md"></video>
                )}
              </div>
            ))}
          </div>
          <p className="text-sm text-gray-600 mb-1">Plataforma: {ad.platform}</p>
          <p className="text-sm text-gray-600 mb-1">País: {ad.country}</p>
          <p className="text-sm text-gray-600 mb-4">Data de Início: {ad.startDate}</p>
          <a
            href={ad.link}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-blue-500 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-blue-600 transition duration-300"
          >
            Ver na Meta Ad Library
          </a>
        </div>
      ))}
    </div>
  );
}


