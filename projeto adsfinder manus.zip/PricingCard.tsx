interface PricingCardProps {
  planName: string;
  price: string;
  features: string[];
  isFake: boolean;
}

export default function PricingCard({ planName, price, features, isFake }: PricingCardProps) {
  return (
    <div className={`bg-white rounded-xl shadow-lg p-8 ${isFake ? 'border-2 border-dashed border-gray-300' : 'border-2 border-blue-600'}`}>
      <h3 className="text-3xl font-bold text-gray-900 mb-4">{planName}</h3>
      <p className="text-5xl font-extrabold text-blue-600 mb-6">{price}<span className="text-xl text-gray-500">/mês</span></p>
      <ul className="space-y-3 mb-8">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center text-gray-700">
            <svg className="w-6 h-6 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
            {feature}
          </li>
        ))}
      </ul>
      {isFake ? (
        <button className="w-full bg-gray-200 text-gray-700 px-6 py-3 rounded-lg text-lg font-semibold cursor-not-allowed">
          Entrar na Lista de Espera
        </button>
      ) : (
        <button className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700 transition duration-300">
          Assinar Agora
        </button>
      )}
    </div>
  );
}


