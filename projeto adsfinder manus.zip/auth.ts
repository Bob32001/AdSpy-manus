import { createClient } from '@supabase/supabase-js';
import { SupabaseAdapter } from '@auth/supabase-adapter';

export const supabase = createClient(
  process.env.SUPABASE_URL as string,
  process.env.SUPABASE_ANON_KEY as string
);

export const SupabaseAuthAdapter = SupabaseAdapter({
  url: process.env.SUPABASE_URL as string,
  secret: process.env.SUPABASE_SERVICE_ROLE_KEY as string,
});


