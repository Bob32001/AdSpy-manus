import Link from "next/link";

export default function Header() {
  return (
    <header className="bg-white shadow-sm py-4">
      <div className="container mx-auto flex justify-between items-center px-4">
        <Link href="/" className="text-2xl font-bold text-gray-900">
          Ads Finder
        </Link>
        <nav>
          <ul className="flex space-x-6">
            <li>
              <Link href="/pricing" className="text-gray-600 hover:text-blue-600 transition duration-300">
                Preços
              </Link>
            </li>
            <li>
              <Link href="/dashboard" className="text-gray-600 hover:text-blue-600 transition duration-300">
                Dashboard
              </Link>
            </li>
            <li>
              <Link href="/login" className="text-blue-600 hover:text-blue-700 transition duration-300 font-semibold">
                Login
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}


