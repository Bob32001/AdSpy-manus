
import React from 'react';

interface WaitlistModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function WaitlistModal({ isOpen, onClose }: WaitlistModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-8 rounded-xl shadow-lg max-w-md w-full">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Junte-se à Lista de Espera Premium</h2>
        <p className="text-gray-700 mb-6">Deixe seu e-mail para ser notificado quando o plano Premium estiver disponível e receba acesso antecipado a novos recursos!</p>
        <form>
          <input
            type="email"
            placeholder="Seu melhor e-mail"
            className="w-full border border-gray-300 rounded-md shadow-sm p-3 mb-4"
            required
          />
          <button
            type="submit"
            className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700 transition duration-300"
          >
            Entrar na Lista de Espera
          </button>
        </form>
        <button
          onClick={onClose}
          className="mt-4 text-gray-500 hover:text-gray-700 transition duration-300"
        >
          Fechar
        </button>
      </div>
    </div>
  );
}


